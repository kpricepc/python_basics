count = 1
while count < 102:
    print(count)
    count += 1