count = 100
while count > 0:
    print(count)
    count -= 1