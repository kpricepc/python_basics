count = 0
while count < 100:
    print(count)
    count += 1