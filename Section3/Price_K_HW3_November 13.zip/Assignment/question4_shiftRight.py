user_input = input("Input a string: ")

string = user_input[-1:] + user_input[:-1]

print(string)