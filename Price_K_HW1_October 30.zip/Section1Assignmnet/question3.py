# Start Question #3
print("Question #3 - Form a Sentence from Inputs")
name = input("Please provide your name: " )
age = input("Please provide your age: ")
print("My name is " + str(name) + ", and my age is " + str(age) + "." )