# Start Question #1 - About Me
print("Question #1")
print("Name: Kevin Price")
print("Address: 2602 Falcon Dr. Longmont CO, 80503")
print("Phone: 817-798-8951")