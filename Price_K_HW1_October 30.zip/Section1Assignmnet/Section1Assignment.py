# Start Question #1 - About Me
print("Question #1")
print("Name: Kevin Price")
print("Address: 2602 Falcon Dr. Longmont CO, 80503")
print("Phone: 817-798-8951")
print("")
# End Question #1

print("")

# Start Question #2
print("Question #2 - Area of Circle")
import math
radius = input("Please provide the Radius: ")
area =  3.14 * float(radius) ** 2
print( "The area is " + str(area) )
# End Question #2

print("")

# Start Question #3
print("Question #3 - Form a Sentence from Inputs")
name = input("Please provide your name: " )
age = input("Please provide your age: ")
print("My name is " + str(name) + ", and my age is " + str(age) + "." )
# End Question #3

print("")

# Start Question #4
print("Question #4 - Calculate minutes in year.")
days_in_year,hours_in_day,minutes_in_hour = 365,24,60
print("There are " + str(days_in_year*hours_in_day*minutes_in_hour) + " minutes in a year.")
# End Question #4

print("")

# Start Question #5
print("Question #5 - Employee Week pay")

overtime_multiplyer = 1.5

wage = float(input("Please input the Employee's hourly wage: "))
standard_hours = float(input("Please input the Employee's Standard Hours: "))
overtime_hours = float(input("Please input the Employee's Overtime Hours: "))

standard_pay = float(standard_hours*wage)
overtime_pay = float(overtime_hours*wage*overtime_multiplyer)
total_pay = standard_pay + overtime_pay

print("The emplyee's total pay for this week is $" + str(total_pay) )