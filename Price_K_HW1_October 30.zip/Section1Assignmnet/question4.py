# Start Question #4
print("Question #4 - Calculate minutes in year.")
days_in_year,hours_in_day,minutes_in_hour = 365,24,60
print("There are " + str(days_in_year*hours_in_day*minutes_in_hour) + " minutes in a year.")