# Start Question #2
print("Question #2 - Area of Circle")
import math
radius = input("Please provide the Radius: ")
area =  3.14 * float(radius) ** 2
print( "The area is " + str(area) )