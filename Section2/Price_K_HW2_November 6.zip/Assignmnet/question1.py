# Count number of spaces in a sentence.
mySentence = "Count number of spaces in a sentence."
print(mySentence)
print("There are " + str(mySentence.count(" ")) + " spaces in the sentence above.")