# Take three inputs and display as list.
myList = ()
x = input("First of three inputs: ")
y = input("Second of three inputs: ")
z = input("Third of three inputs: ")
myList = (x, y ,z)
print(myList)